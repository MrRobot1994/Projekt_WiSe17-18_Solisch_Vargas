#ifndef KLASSECOMIC_H_INCLUDED
#define KLASSECOMIC_H_INCLUDED
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

string getAttributeValue (string attributeName, string& line);
string getTagValue(string tagName, string& line);

class Comic{
public:
    string id{};
    string name{};
    string label{};
    string artist{};
    string writer{};
    string year{};
    string series{};
    string vol{};
    string issue{};
    string merchandise{};
    string clothes{};
    string toys{};
    string movies{};
    string games{};
    string comics{};
    explicit Comic(string comicXML[18]); //explicit sollte angegeben werden, da es vom compiler verlangt wird
    vector <string> toXML();
    void ausgeben();
};

Comic::Comic (string *comicXML) {
    id = getAttributeValue("hero_id", comicXML[1]); //an welcher arraystelle der wert zu holen ist
    name =getTagValue("name", comicXML[1]); //name und id befinden sich in der gleichen tagzeile->[1]
    label = getTagValue("label", comicXML[2]);
    artist = getTagValue("artist", comicXML[4]);
    writer = getTagValue("writer", comicXML[5]);

    year = getTagValue("year", comicXML[8]);

    series = getTagValue("series", comicXML[9]);
    vol = getTagValue("vol", comicXML[11]);
    issue = getTagValue("issue", comicXML[12]);

}


// Da bisher nur die Infotmationen zwischen den Tags ausgelesen wurden, werden hier die Start- und Endtags wieder hinzugef�gt,
// damit die neu konvertierte Datei so aussieht, wie es in der Vorgabe verlangt wurde.

vector<string> Comic::toXML() {
    vector<string> lines;
    /* lines.push_back("<comic xml:id= "+id+">");
     lines.push_back("<persName>");
     lines.push_back("<forename>" + vorname + "</forename>");
     lines.push_back("<surname>" + nachname + "</surname>");
     lines.push_back("</persName>");
     lines.push_back("<birth when= " + geburtsdatum + "</birth>");
     lines.push_back("</comic>");
     */

    lines.push_back("<name hero_id= \""+id+"\">");
    lines.push_back("<label>"+ label + "</label>");
    lines.push_back("<artist>"+ artist + "</artist>");
    lines.push_back("<writer>" + writer + "</writer>");
    lines.push_back("<year>" + year + "</year>");
    lines.push_back("<series>" + series + "</series>");
    lines.push_back("<vol>" + vol + "</vol>");
    lines.push_back("<issue>" + issue + "</issue>");

    lines.push_back("<Merchandise>"+merchandise+"</merchandise>");
    lines.push_back("<clothes>"+clothes+"</clothes>");
    lines.push_back("<toys>"+toys+"</toys>");
    lines.push_back("<movies>"+movies+"</movies>");
    lines.push_back("<games>"+games+"</games>");
    lines.push_back("<comics>"+comics+"</comics>");



    // F�r Games, Toys, etc....


    return lines;
}

void Comic::ausgeben(){
    cout << "ID:" << id<<endl;
    cout << " - Label: " << label<<endl;
    cout << " - Artist: " << artist<<endl;
    cout << " - Writer: " << writer<<endl;
    cout << " - Year: " << year<<endl;
    cout << " - Series: " << series<<endl;
    cout << " - Vol: " << vol<<endl;
    cout << " - Issue: " << issue<<endl;
    cout << " - Merchandise: " << merchandise<<endl;
    cout << " - Clothes: " << clothes<<endl;
    cout << " - Toys: " << toys<<endl;
    cout << " - Movies: " << movies<<endl;
    cout << " - Games: " << games<<endl;
    cout << " - Comics: " << comics << endl;
}



#endif // KLASSEcomic_H_INCLUDED
