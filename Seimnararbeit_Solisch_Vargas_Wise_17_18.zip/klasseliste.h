#ifndef KLASSELISTE_H_INCLUDED
#define KLASSELISTE_H_INCLUDED
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

class Liste {
private:
public:
    enum searchCategories{id=0, name=1, label=2, artist=3, writer=4, year=5, series=6, vol=7, issue=8, merchandise=9, clothes=10,
        toys=11, movies=12, games=13, comics=14};
    void add(Comic comic);
    void print();
    void readXML();
    void readMerch();
    Comic * search(searchCategories category, string searchValue);
    void toXML(const string outputFileName);
    vector<Comic> comicsListe;

};
void Liste::add(Comic comic) {
    comicsListe.push_back(comic);
}
void Liste::print() {
    for(size_t i = 0; i < comicsListe.size(); i++) {
        Comic tempComic = comicsListe.at(i);
        tempComic.ausgeben();

    }
}

// Einlesen der .xml-Datei zum Auslesen der Superhelden
void Liste::readXML(){
    ifstream file("superhero.xml");
    vector<string> lineStrings;

    // TODO : F�r Textfile kopieren und anpassen!!!
    for(string line; getline(file,line);){
        lineStrings.push_back(line);
    }


    lineStrings.erase(lineStrings.begin());     //.erase l�scht den Inhalt des Objektes
    lineStrings.erase(lineStrings.begin());     //.erase l�scht den Inhalt des Objektes
    lineStrings.erase(lineStrings.begin());     //.erase l�scht den Inhalt des Objektes
    lineStrings.erase(lineStrings.begin());     //.erase l�scht den Inhalt des Objektes

    lineStrings.pop_back();                     //.pop_back l�scht den letzten Char eines Strings

    // Wir gehen davon aus, dass die Informationen zu den einzelnen comics in der XML-Datei aus genau 6 Elementen besteht,
    // Bsp: 1. <Comic xml:id="123"> 2. <persName> 3. <forename>Paul</forename> 4. <surname>Biegler</surname> 5. </persName> 6. </Comic>
    // Sollte dies nicht der Fall sein, funktioniert der Code nicht

    // Lese Zeilen einzeln ein und erstelle Objektes
    for(size_t i = 0; i< lineStrings.size(); i += 18) {
        string comicXMLlines[18];
        for (int j = 0; j < 18; ++j) {
            comicXMLlines[j] = lineStrings.at(i+j);
        }
        i++;
        Comic comic(comicXMLlines);
        comicsListe.push_back(comic);        //.push_back erweitert das Objekt um ein weiteres Element
    }

}

//Einlesen der .txt-Datei zum Auslesen der Geburtstage

void Liste::readMerch() {
    ifstream file("superhero.txt");
    vector<string> werte;

  /*  for(string line; getline(file, line);) {
        string personID = line.substr(0,line.find(' '));
        search(id,personID)->merchandise = line.substr(line.find(' ') +1);
    }*/
}

//switch-case (da wir wissen, wie viele M�gliche F�lle es gibt) um die 4 Kategorien ID, Vorname, Nachname und Geburtstag zusammen zu fassen

Comic * Liste::search(searchCategories category, string searchValue) {
    for(size_t i = 0; i < comicsListe.size(); i++) {
        Comic tempComic = comicsListe.at(i);

        switch(category) {
            case id:
                if (tempComic.id == searchValue){
                    return &comicsListe.at(i);
                }
                break;
            case name:
                if (tempComic.name.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case label:
                if (tempComic.label.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case artist:
                if (tempComic.artist.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case writer:
                if (tempComic.writer.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case year:
                if (tempComic.year.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case series:
                if (tempComic.series.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case vol:
                if (tempComic.vol.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case issue:
                if (tempComic.issue.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case merchandise:
                if (tempComic.merchandise.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case clothes:
                if (tempComic.clothes.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case toys:
                if (tempComic.toys.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case movies:
                if (tempComic.movies.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case games:
                if (tempComic.games.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;
            case comics:
                if (tempComic.comics.compare(searchValue) == 0) {
                    return &comicsListe.at(i);
                }
                break;


        }

    }
    return NULL;
}


void Liste::toXML (const string outputFileName)  {

    ofstream xmlFile;
    //fout.open(filename.c_str());
    xmlFile.open(outputFileName.c_str());
    xmlFile << "<listcomic> \n";
    for(size_t i = 0; i < comicsListe.size(); ++i) {
        vector<string> tempComicStrings = comicsListe.at(i).toXML();

        for(size_t j = 0; j < tempComicStrings.size(); ++j) {
            xmlFile << tempComicStrings.at(j) << "\n";
        }
    }
    xmlFile << "<\\listcomic> \n";
    xmlFile.close();

}



#endif // KLASSELISTE_H_INCLUDED
